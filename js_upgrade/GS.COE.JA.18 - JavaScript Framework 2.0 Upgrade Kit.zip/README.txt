NOTE: This is the upgrade kit for version 2.0. Only use this file on 
a site that already has v1 of the Framework installed. If you are installing
the framework for the first time, refer to GS.COE.JA.05 - JavaScript Starter
Kit.

To get started with the upgrade:

Upload all files in javascript.zip to the 'javascript' folder on your 
target site.

You will most likely overwrite "return_to_quote_button.js" and 
"allplugins-require.js." This is okay.

Click on the link for "upgrade.html" in the File Manager.

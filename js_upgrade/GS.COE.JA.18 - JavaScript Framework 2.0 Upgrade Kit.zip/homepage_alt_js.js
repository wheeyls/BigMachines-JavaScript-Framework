/* 
 * BigMachines JavaScript Framework v2 parameter
 * This optional parameter helps the javascript framework to identify the home page
*/
window["framework/homepage"] = true;
